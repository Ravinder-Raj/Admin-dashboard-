import BarChart from "./BarChart";
import jsonData from "../data/data.json";
import StackedBarChart from "./StackedBarChart";
import LineChart from "./LineChart";
import PieChart from "./PieChart";
import React, { useEffect, useState } from "react";
import axios from "axios";
import like from "../assets/pngwing.com.png";

const monthlyData = jsonData.performanceData.monthlyData;
const colors = ["#1f77b4", "#ff7f0e", "#2ca02c"];
const legends = ["Likes", "Comments", "Shares"];

const Dashboard = () => {
  const totalViews = monthlyData.reduce((acc, data) => acc + data.views, 0);
  const totalLikes = monthlyData.reduce((acc, data) => acc + data.likes, 0);
  const totalComments = monthlyData.reduce(
    (acc, data) => acc + data.comments,
    0
  );
  const totalShares = monthlyData.reduce((acc, data) => acc + data.shares, 0);

  const [articles, setArticles] = useState([]);

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const response = await axios.get(
          "https://newsapi.org/v2/top-headlines",
          {
            params: {
              pageSize: 3,
              country: "in",
              apiKey: "93b54445377142d6a87abe3f96e223aa", // Replace with your actual API key
            },
          }
        );

        setArticles(response.data.articles);
      } catch (error) {
        console.error("Error fetching articles:", error);
      }
    };

    fetchArticles();
  }, []);

  return (
    <>
      <h1 className="absolute text-2xl">Dashboard</h1>
      <div className="flex   max-lg:flex-col  w-full   bg-slate-800  justify-around">
        <div className="grid grid-cols-2  max-lg:p-0 max-lg:mt-8 max-md:flex max-md:flex-col max-lg:w-full border border-black max-lg:h-full h-[35rem]  lg:w-3/4    bg-red-500 ">
          {/* <Barchart data={monthlyData} width={600} height={400} /> */}
          <div className="border border-green m-auto">
            <h1>Login Activity</h1>
            <BarChart
              data={monthlyData}
              width={300}
              height={200}
              barWidth={30}
              barColor="skyblue"
            ></BarChart>
          </div>
          <div className="border border-white m-auto">
            {" "}
            <h1>Session Activity</h1>
            <StackedBarChart
              data={jsonData.performanceData}
              width={300} // specify desired width
              height={200} // specify desired height
              color="skyblue"
            />
          </div>
          <div className="border border-white m-auto">
            {" "}
            <h1>Activite users</h1>
            <LineChart
              data={jsonData.performanceData}
              width={300} // specify desired width
              height={200} // specify desired height
              color="skyblue"
            />
          </div>
          <div className="border border-white m-auto">
            {" "}
            <h1>Action taken</h1>
            <PieChart
              data={jsonData.performanceData}
              width={190}
              height={200}
              colors={colors}
              legends={legends}
            />
          </div>
        </div>
        <div className="border border-black w-3/12 max-lg:w-full flex flex-col">
          <div className="border border-black h-20 m-auto">
            {" "}
            <button className="w-48 h-20  bg-sky-300 border border-white rounded-md text-white text-2xl">Create news feed</button>
          </div>
          <div className="border border-black h-[28rem]  flex flex-col   ">
            <h1 className="text-3xl text-center">Performance</h1>
            <div className=" h-[28rem] grid grid-cols-2 m-auto gap-12  ">
              <div>
                <h1 className="border border-black text-3xl w-28   flex flex-col float-left">
                  <img className="w-9" src={like} alt="" />
                  <p className="  text-base  ">Total likes</p>
                  <h1 className="text-4xl  ">{totalLikes}</h1>
                </h1>
              </div>
              <div>
                <h1 className="border border-black text-3xl w-32  flex flex-col float-left">
                  <img className="w-9" src={like} alt="" />
                  <p className="  text-base  ">Total Comments</p>
                  <h1 className="text-4xl  ">{totalComments}</h1>
                </h1>
              </div>
              <div>
                <h1 className="border border-black text-3xl w-28   flex flex-col float-left">
                  <img className="w-9" src={like} alt="" />
                  <p className="  text-base  ">Total Shares</p>
                  <h1 className="text-4xl  ">{totalShares}</h1>
                </h1>
              </div>
              <div>
                <h1 className="border border-black text-3xl w-28   flex flex-col float-left">
                  <img className="w-9" src={like} alt="" />
                  <p className="  text-base  ">Total Views</p>
                  <h1 className="text-4xl  ">{totalViews}</h1>
                </h1>
              </div>
            </div>
            <div className=" m-auto">
              {" "}
              <button className="w-44 h-14 border bg-sky-300  border-white rounded-md  text-white text-2xl">
                View All
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="w-full ">
      <div className="w-[99%] bg-green-500 m-auto h-[18rem] scroll-m-4 border rounded-xl mt-3">
        <div className="flex justify-between px-5   ">
          <div>
            <h1 className="text-3xl text-white">News feeds</h1>   
          </div>
          <div>
            <button className="border  bg-sky-300  border-white rounded-md h-14   ">
              <h1 className="text-2xl text-white ">Manage News Feed</h1>
            </button>
          </div>
        </div>
        <div className="overflow-x-auto text-white ">
          <table className="table-auto w-full">
            <thead>
              <tr>
                <th className="px-4 py-2 w-28">Sr. No</th>
                <th className="px-4 py-2 w-96">Title</th>
                <th className="px-4 py-2 w-32 max-sm:hidden">Category</th>
                <th className="px-4 py-2 w-48 max-sm:hidden ">Date</th>
                <th className="px-4 py-2 w-48">Status</th>
              </tr>
            </thead>
            <tbody>
              {articles.map((article, index) => (
                <tr key={index}>
                  <td className="border px-4 py-2 ">{index + 1}</td>
                  <td className="border px-4 py-2">{article.title}</td>
                  <td className="border px-4 py-2 max-sm:hidden">All</td>
                  <td className="border px-4 py-2 max-sm:hidden">
                    {article.publishedAt}
                  </td>
                  <td className="border px-4 py-2">Published</td>
                </tr>
              ))}
              {/* <tr>
                <td className="border px-4 py-2">1</td>
                <td className="border px-4 py-2">{articles.title}</td>
                <td className="border px-4 py-2">Category A</td>
                <td className="border px-4 py-2">2024-03-24</td>
                <td className="border px-4 py-2">Active</td>
              </tr> */}
              {/* <tr>
                <td className="border px-4 py-2">2</td>
                <td className="border px-4 py-2">{articles.title}</td>
                <td className="border px-4 py-2">Category B</td>
                <td className="border px-4 py-2">2024-03-25</td>
                <td className="border px-4 py-2">Inactive</td>
              </tr>
              <tr>
                <td className="border px-4 py-2">3</td>
                <td className="border px-4 py-2">{articles.title}</td>
                <td className="border px-4 py-2">Category C</td>
                <td className="border px-4 py-2">2024-03-26</td>
                <td className="border px-4 py-2">Active</td>
              </tr> */}
            </tbody>
          </table>
        </div>
      </div>
      </div>
    </>
  );
};

export default Dashboard;
